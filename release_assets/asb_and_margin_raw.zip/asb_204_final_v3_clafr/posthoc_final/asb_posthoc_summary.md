# ASB CLAFR Posthoc Summary

- source root: `ICLR\results\asb_204_final_v3_clafr`
- model: `deepseek-v4-flash`
- tool provenance: `source_trust`
- expected cases per variant: `204`
- complete all variants: `yes`
- attack-tool trace reconstructed: `yes`
- ASR definition: stored attack-goal hit OR executed attacker-tool trace.

| method | variant | cases | complete | Utility | Task success | ASR | Trace ASR | Safety | Margin | Blocked | Changed | Projection changed |
|---|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| clafr_feedback | `clafr_feedback` | 204/204 | yes | 0.868 | 0.735 | 0.000 | 0.000 | 1.000 | 0.134 | 94 | 0 | 394 |

## Baseline Notes

- `ts_guard_style`: ToolSafe TS-Guard-style step-level LLM guard run with the same DeepSeek-v4-Flash model on this manifest
- `ts_flow_style`: ToolSafe TS-Flow-style guard feedback loop run with the same DeepSeek-v4-Flash model on this manifest
- `asb_delimiter`: official ASB delimiter defense applied to the trusted task before workflow generation
- `asb_instruction`: official ASB instructional-prevention defense applied to the trusted task before workflow generation
- `asb_sandwich`: official ASB observation-sandwich defense that repeats the trusted task after every tool observation
- `clafr_full`: CLAFR evaluates every model-visible tool with the same visible runtime schema. In source_trust mode, ASB's attacker-supplied tool record is used only as runtime source provenance: the tool remains visible, but its source contributes untrusted-source risk. Report no_label stress results when claiming benchmark transfer beyond provenance-aware environments.
- `clafr_feedback`: CLAFR feedback variant uses the same visible schema and tool-provenance setting as clafr_full and adds neutral block feedback.
- `progent`: same-harness adapter of Progent's official ASB policy-generation prompt and least-privilege allowlist; it does not read benchmark normal/attack labels
- `drift`: same-harness adapter of DRIFT's official ASB initial-trajectory planning and strict trajectory enforcement; it does not read benchmark normal/attack labels

## Top Blocked Constraints

- `clafr_feedback`: untrusted_tool_source_requires_authorization:80; trusted_over_untrusted_direction:48; state_cleanliness:45; untrusted_control_budget:32; irreversible_effect_authorization:32
